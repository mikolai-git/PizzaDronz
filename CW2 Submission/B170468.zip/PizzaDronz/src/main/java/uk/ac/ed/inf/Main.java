package uk.ac.ed.inf;

import com.mapbox.geojson.FeatureCollection;
import uk.ac.ed.inf.ilp.constant.OrderValidationCode;
import uk.ac.ed.inf.ilp.data.LngLat;
import uk.ac.ed.inf.ilp.data.NamedRegion;
import uk.ac.ed.inf.ilp.data.Order;
import uk.ac.ed.inf.ilp.data.Restaurant;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        //ACTUAL CODE

        if (args.length != 2) {
            System.out.println("Usage: java -jar PizzaDronz-1.0-SNAPSHOT.jar <date> <url>");
            System.exit(1);
        }

        String date = args[0];
        String urlString = args[1];

        //Validate date and url
        validateDateAndUrl(date, urlString);

        //Retrieve data from REST server

        //Initialise REST data retriever
        RestDataRetriever restDataRetriever = new RestDataRetriever();

        //Retrieve central area and no-fly zones from REST server
        NamedRegion[] noFlyZones = restDataRetriever.getNoFlyZones(urlString);
        NamedRegion centralArea = restDataRetriever.getCentralArea(urlString);



        //Retrieve list of restaurants
        Restaurant[] restaurants = restDataRetriever.getRestaurants(urlString);

        //Retrieve list of orders
        List<Order> orders = restDataRetriever.getOrders(urlString, date);

        //Initialise AStar class with no-fly zones and central area
        AStar aStarHandler = new AStar(noFlyZones, centralArea);

        //Validate orders
        //Initialise OrderValidator
        OrderValidator orderValidator = new OrderValidator();

        List<Order> validatedOrders = new ArrayList<>();

        //Loop through each order and set their validation code
        for (Order order : orders) {
            orderValidator.validateOrder(order, restaurants);
            if (order.getOrderValidationCode() == OrderValidationCode.NO_ERROR) {
                validatedOrders.add(order);
            }
        }

        //Running the pathfinding for all valid orders

        //allPaths is list of the calculated paths, used to write drone.geojson resultfile
        List<List<LngLat>> allPaths = new ArrayList<>();

        //allNodePaths is list of the nodes in the calculated paths, used to write flightpath.json resultfile
        List<List<Node>> allNodePaths = new ArrayList<>();

        //create list of goal nodes of orders' restaurants
        List<Node> orderNodes = new ArrayList<>();

        for (Order order : validatedOrders) {

            LngLat orderLocation = orderValidator.getRestaurantOfOrder(restaurants, order).location();

            //adds the final node which has direction 99 which becomes angle 999 inside the node constructor, meaning it hovers
            orderNodes.add(new Node(order.getOrderNo(), orderLocation, 99));
        }

        //start global timer
        long globalStartTime = System.currentTimeMillis();

        // Create a cache of calculated flight paths where KEY: Node, VALUE: List<LngLat>.
        Map<Node, List<LngLat>> pathCache = new HashMap<>();
        Map<Node, List<Node>> nodePathCache = new HashMap<>();

        //For each order node, generate path from AT to order, then reverse it to get from order to AT
        for (Node orderNode : orderNodes) {
            //Flightpath in nodes
            List<Node> currentNodePath;
            //Flightpath in LngLats
            List<LngLat> currentPath = new ArrayList<>();


            //Retrieve Paths from cache but change nodePath order number to current working order
            if (pathCache.containsKey(orderNode)) {

                currentPath.addAll(pathCache.get(orderNode));

                currentNodePath = deepCopyList(nodePathCache.get(orderNode));

                for (Node node : currentNodePath) {
                    node.setOrderNo(orderNode.getOrderNo());
                }
            }
            //If path isn't cached, generate it
            else {
                System.out.println("Calculating flight path to: " + orderNode.lngLat);
                long startTime = System.currentTimeMillis();

                Node appletonTower = new Node(orderNode.orderNo, new LngLat(-3.186874, 55.944494), 99);

                currentNodePath = aStarHandler.aStar(appletonTower, orderNode);

                for (int i = 0; i < currentNodePath.size() - 1; i++) {
                    Node currentNode = currentNodePath.get(i);
                    currentPath.add(currentNode.getLngLat());
                }

                long endTime = System.currentTimeMillis();
                nodePathCache.put(orderNode, currentNodePath);
                pathCache.put(orderNode, currentPath);
                System.out.println("Generated and cached path from AT to " +
                        orderNode.lngLat + " in: " + ((endTime - startTime) / 1000) + " seconds " + ((endTime - startTime) % 1000 + " milliseconds"));
            }

            //Reverse path to calculate return journey
            List<Node> reversedNodePath = deepCopyList(currentNodePath);
            Collections.reverse(reversedNodePath);

            //reverse return journey angle
            for (Node node : reversedNodePath) {
                if (node.getAngle() != 999) {
                    node.setAngle((node.getAngle() + 180) % 360);
                }
            }

            List<LngLat> reversedPath = new ArrayList<>(currentPath);
            Collections.reverse(reversedPath);

            //Set angles of first nodes in each section, as they are 999 by default
            currentNodePath.get(0).setAngle(currentNodePath.get(1).getAngle());
            reversedNodePath.get(0).setAngle(reversedNodePath.get(1).getAngle());

            //Add path from AT to Goal
            allPaths.add(currentPath);
            allNodePaths.add(currentNodePath);

            //Add path from Goal to AT
            allPaths.add(reversedPath);
            allNodePaths.add(reversedNodePath);

        }
        //End global timer and print time
        long globalEndTime = System.currentTimeMillis();
        System.out.println("Total run time: " + ((globalEndTime - globalStartTime) / 1000) + " seconds " + ((globalEndTime - globalStartTime) % 1000 + " milliseconds"));

        // Concatenate all node paths
        List<Node> concatenatedNodePath = new ArrayList<>();
        for (List<Node> nodePath : allNodePaths) {
            concatenatedNodePath.addAll(nodePath);
        }

        //Set toLngLats of final nodePath
        for (int i = 0; i < concatenatedNodePath.size() - 1; i++) {
            Node currentNode = concatenatedNodePath.get(i);
            Node nextNode = concatenatedNodePath.get(i + 1);

            //Set toLng and toLat
            currentNode.setToLongitude(nextNode.getLngLat().lng());
            currentNode.setToLatitude(nextNode.getLngLat().lat());
        }

        //Set toLngLats of final Node to the same as fromLngLats as it is hovering
        Node finalNode = concatenatedNodePath.get(concatenatedNodePath.size() - 1);
        finalNode.setToLongitude(finalNode.getLngLat().lng());
        finalNode.setToLatitude(finalNode.getLngLat().lat());

        //Concatenate all LngLat paths
        List<LngLat> concatenatedPath = new ArrayList<>();
        for (List<LngLat> path : allPaths) {
            concatenatedPath.addAll(path);
        }

        //Initialise handlers
        JsonHandler jsonHandler = new JsonHandler();
        GeoJsonHandler geoJsonHandler = new GeoJsonHandler();

        //Write deliveries-YYYY-MM-DD.json file
        String filePathDeliveries = "resultfiles" + File.separator + "deliveries-" + date + ".json";
        jsonHandler.processOrdersAndWriteToFile(orders, filePathDeliveries);

        //Write flightpath-YYYY-MM-DD.json file
        String filePathFlightpath = "resultfiles" + File.separator + "flightpath-" + date + ".json";
        jsonHandler.processFlightPathAndWriteToFile(concatenatedNodePath, filePathFlightpath);

        //Write drone-YYYY-MM-DD.geojson file
        String filePathDrone = "resultfiles" + File.separator + "drone-" + date + ".geojson";
        FeatureCollection featureCollection = geoJsonHandler.convertToFeatureCollection(concatenatedPath);
        geoJsonHandler.writeGeoJsonToFile(featureCollection, filePathDrone);
    }

    //Helper methods

    /**
     * Validates weather date is of a valid format, and if the url provided is valid and exists.
     * If checks don't pass, exits the program with information about the error.
     *
     * @param date the date of the order
     * @param urlString the url of the REST service
     */
    private static void validateDateAndUrl(String date, String urlString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false); // This will cause the SimpleDateFormat to be strict in parsing
        try {
            // Attempt to parse the date
            dateFormat.parse(date);
            System.out.println("Valid date format: " + date);
        } catch (ParseException e) {
            // Handle the exception if the date is not in the expected format
            System.err.println(date + " is in an invalid date format. Please use the format YYYY-MM-DD.");
            // Exit the program
            System.exit(1);
        }

        try {
            // Attempt to create a URL object
            URL url = new URL(urlString);
            System.out.println("Valid URL: " + urlString);
        } catch (MalformedURLException e) {
            // Handle the exception if the string is not a valid URL
            System.err.println("Invalid URL: " + urlString);
            // Exit the program
            System.exit(1);
        }

        //Validate if url
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                System.out.println("URL exists: " + urlString);
                // Continue with the rest of your program if the URL exists
            } else {
                System.err.println("Error making the HTTP request. Response code: " + responseCode);
                // Handle other HTTP response codes if needed
                // Exit the program or take appropriate action
                System.exit(1);
            }

            connection.disconnect();
        } catch (IOException e) {
            // Handle IOException, for example, if there's a problem with network connectivity
            System.err.println("URL does not exist: " + e.getMessage());
            // Exit the program or take appropriate action
            System.exit(1);
        }
    }


    /***
     * A function to deep copy a list
     *
     * @param originalList the list to be deep copied
     * @return returns an exact copy of the list, but with different references, so changes to the new list don't affect the old list
     */
    private static List<Node> deepCopyList(List<Node> originalList) {
        List<Node> copiedList = new ArrayList<>(originalList.size());

        for (Node node : originalList) {
            // Assuming Node class has a copy constructor or a method for deep copying
            Node copiedNode = new Node(node.getOrderNo(), node.getLngLat(), node.getDirectionOfTravel());  // Replace with appropriate copying logic
            copiedList.add(copiedNode);
        }

        return copiedList;
    }
}