package uk.ac.ed.inf;

import uk.ac.ed.inf.ilp.constant.SystemConstants;
import uk.ac.ed.inf.ilp.data.LngLat;
import uk.ac.ed.inf.ilp.data.NamedRegion;

import java.util.*;
import java.lang.*;


public class AStar {

    NamedRegion[] noFlyZones;
    NamedRegion centralArea;

    static LngLatHandler lngLatHandler = new LngLatHandler();

    AStar(NamedRegion[] noFlyZones, NamedRegion centralArea){
        this.noFlyZones = noFlyZones;
        this.centralArea = centralArea;
    }

    /**
     * Implementation of the A* pathfinding algorithm tailored to the project's needs
     *
     *
     * @param start the starting Node of the path, in practice always Appleton Tower
     * @param goal the goal Node of the path, in practice a restaurant
     * @return List of nodes in order from the starting node to goal node, forming a path, nodes contain coordinates and direction
     */
    public List<Node> aStar(Node start, Node goal) {

        // Priority queue to store nodes in order of their fCost
        PriorityQueue<Node> openSet = new PriorityQueue<>();

        // Set to store nodes that have been visited
        Set<Node> closedSet = new HashSet<>();

        //Initialise costs for the start node
        start.gCost = 0;
        start.hCost = lngLatHandler.distanceTo(start.lngLat, goal.lngLat);
        start.fCost = start.gCost + start.hCost;

        // Add the start node to the open set
        openSet.add(start);

        // Loop until the open set is empty
        while (!openSet.isEmpty()) {

            // Get the node with the lowest fCost from the open set
            Node currentNode = openSet.poll();

            // If the current node is close to the goal, reconstruct and return the path
            if (lngLatHandler.distanceTo(currentNode.lngLat, goal.lngLat) <= SystemConstants.DRONE_IS_CLOSE_DISTANCE) {

                List<Node> path = new ArrayList<>();
                // Reconstruct the path by backtracking from the goal to the start
                boolean isFirstIteration = true;

                while (currentNode != null) {
                    if (isFirstIteration) {
                        // Code for the first iteration
                        path.add(new Node(currentNode.orderNo, currentNode.lngLat, 99));
                        isFirstIteration = false;
                    } else {
                        // Code for subsequent iterations
                        path.add(new Node(currentNode.orderNo, currentNode.lngLat, currentNode.directionOfTravel));
                    }

                    currentNode = currentNode.parent;
                }
                // Reverse the path to get it from start to goal
                Collections.reverse(path);
                return path;
            }

            // Mark the current node as visited
            closedSet.add(currentNode);
            //System.out.println("Marked as visited:" + currentNode.lngLat);

            double DIRECTION_CHANGE_COST = 0.00015;

            // Explore neighbors of the current node
            for (Node neighbour : generateNeighbours(currentNode, noFlyZones)) {
                // Skip neighbors that have already been visited
                if (closedSet.stream().anyMatch(closedNode -> closedNode.lngLat.equals(neighbour.lngLat))) {
                    continue;
                }

                // Calculate the tentative cost from the start to this neighbour
                double tentativeGCost = currentNode.gCost + lngLatHandler.distanceTo(currentNode.lngLat, neighbour.lngLat);

                // Update the heuristic value for the neighbor
                double heuristicCost = lngLatHandler.distanceTo(neighbour.lngLat, goal.lngLat);

                //Bias the cost if the directions are different
                if (!isWeightPriority1(currentNode.directionOfTravel, neighbour.directionOfTravel)) {
                    tentativeGCost += DIRECTION_CHANGE_COST; // Define DIRECTION_CHANGE_COST as needed
                }

                if (!isWeightPriority2(currentNode.directionOfTravel, neighbour.directionOfTravel)) {
                    tentativeGCost += DIRECTION_CHANGE_COST; // Define DIRECTION_CHANGE_COST as needed
                }

                if (!isWeightPriority3(currentNode.directionOfTravel, neighbour.directionOfTravel)) {
                    tentativeGCost += DIRECTION_CHANGE_COST; // Define DIRECTION_CHANGE_COST as needed
                }



                // If the tentative cost is lower than the current known cost to the neighbor
                if (tentativeGCost < neighbour.gCost) {
                    // Update the cost in the edges map
                    currentNode.addEdge(neighbour.lngLat, tentativeGCost);
                    // Update the cost and heuristic values for the neighbor
                    neighbour.gCost = tentativeGCost;
                    neighbour.hCost = heuristicCost; // Update the heuristic
                    neighbour.fCost = neighbour.gCost + neighbour.hCost;

                    //System.out.println("hCost: " + neighbour.hCost);
                    neighbour.parent = currentNode;



                    // If the neighbor is not in the open set, add it
                    if (!openSet.contains(neighbour)) {
                        openSet.add(neighbour);
                    }

                }

            }


        }
        // If the open set is empty and the goal was not reached, return null (no path found)
        System.out.println("No Path Found");
        return null;
    }

    // Helper method to check if two directions are adjacent
    static boolean isWeightPriority1(int direction1, int direction2) {
        // Assuming directions are in the range [0, 15] for a 16-direction compass
        int diff = Math.abs(direction1 - direction2);
        return diff == 1 || diff == 15 || diff == 0; // Directions are adjacent if the difference is 1 or 15
    }

    static boolean isWeightPriority2(int direction1, int direction2) {
        // Assuming directions are in the range [0, 15] for a 16-direction compass
        int diff = Math.abs(direction1 - direction2);
        return (diff >= 0 && diff <= 3 || diff >= 13 && diff <= 15); // Directions are adjacent if the difference is 1 or 15
    }

    static boolean isWeightPriority3(int direction1, int direction2) {
        // Assuming directions are in the range [0, 15] for a 16-direction compass
        int diff = Math.abs(direction1 - direction2);
        return (diff >= 0 && diff <= 4 || diff >= 12 && diff <= 15); // Directions are adjacent if the difference is 1 or 15
    }

    /**
     * Crucial method for the A* algorithm, generates the possible neighbours of a node, which are then later explored
     *
     * @param node the node who's neighbours are to be generated
     * @param noFlyZones the no-fly zones
     * @return list of Nodes, which are the newly generated neighbours
     */
    static List<Node> generateNeighbours(Node node, NamedRegion[] noFlyZones) {
        List<Node> neighbours = new ArrayList<>();

        for (int direction = 0; direction < 16; direction++) {
            // Skip directions that are less likely to lead to the optimal path
            if (shouldPruneDirection(direction)) {
                continue;
            }

            double angle = Math.toRadians(22.5 * direction);
            double newLng = node.lngLat.lng() + SystemConstants.DRONE_MOVE_DISTANCE * Math.cos(angle);
            double newLat = node.lngLat.lat() + SystemConstants.DRONE_MOVE_DISTANCE * Math.sin(angle);

            LngLat newLngLat = new LngLat(newLng, newLat);

            // Check if the newLngLat is within any of the no-fly zones
            if (!isWithinNoFlyZone(newLngLat, noFlyZones)) {
                // Avoid generating nodes that backtrack to the previous position
                if (direction != getOppositeDirection(node.directionOfTravel)) {
                    Node newNode = new Node(node.orderNo, newLngLat, direction);
                    neighbours.add(newNode);
                }
            }
        }

        return neighbours;
    }

    //Prune every second node, (effectively make it 8 directions of movement)
    static boolean shouldPruneDirection(int direction) {
        return direction % 2 != 0;
    }

    //Get the opposite direction from the one provided
    static int getOppositeDirection(int direction) {
        // Calculate the opposite direction (e.g., direction 0 is opposite to direction 8)
        return (direction + 8) % 16;
    }

    /**
     * uses the lngLatHandler method to find weather a given point is in the no-fly zone
     *
     * @param point Point in LngLat format
     * @param noFlyZones the no-fly zones
     * @return weather the point is in the provided no-fly zones
     */
    static boolean isWithinNoFlyZone(LngLat point, NamedRegion[] noFlyZones) {
        for (NamedRegion noFlyZone : noFlyZones) {
            if (lngLatHandler.isInRegion(point, noFlyZone)) {
                //System.out.println("Found Node in No-Fly");
                return true;  // Point is within a no-fly zone
            }
        }
        return false;  // Point is not within any no-fly zone
    }

}