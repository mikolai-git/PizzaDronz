package uk.ac.ed.inf;

import com.mapbox.geojson.LineString;
import uk.ac.ed.inf.ilp.data.LngLat;
import com.mapbox.geojson.*;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GeoJsonHandler {

    /**
     *
     * @param pathCoordinates list of the coordinates that make up the path, essentially the path itself
     * @return the path as a Feature collection, needed for the geojson format
     */
    FeatureCollection convertToFeatureCollection(List<LngLat> pathCoordinates) {
        LineString lineString = LineString.fromLngLats(convertToPointList(pathCoordinates));
        Feature feature = Feature.fromGeometry(lineString);
        return FeatureCollection.fromFeature(feature);
    }


    /**
     *Writes the drone-YYYY-MM-DD.geojson file
     *
     * @param featureCollection the feature collection to be written
     * @param filePath the filepath where to file should be written
     */
    void writeGeoJsonToFile(FeatureCollection featureCollection, String filePath){
        try (FileWriter fileWriter = new FileWriter(filePath)){
            fileWriter.write(featureCollection.toJson());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     *
     * @param lngLatList list of LngLats
     * @return list of the co-ordinates in Point format
     */
    List<Point> convertToPointList(List<LngLat> lngLatList) {
        List<Point> pointList = new ArrayList<>();

        for (LngLat lngLat : lngLatList) {
            Point point = Point.fromLngLat(lngLat.lng(), lngLat.lat());
            pointList.add(point);
        }

        return pointList;

    }
}

