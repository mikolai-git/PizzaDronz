package uk.ac.ed.inf;

import uk.ac.ed.inf.ilp.data.Order;

import java.io.FileWriter;
import java.io.IOException;

import java.util.List;
import com.google.gson.*;

public class JsonHandler {


    /**
     * Writes the orders-YYYY-MM-DD.json file
     *
     * @param orders List of orders to process
     * @param filePath the filepath to write it to
     */
    void processOrdersAndWriteToFile(List<Order> orders, String filePath) {
        // Create Gson instance
        Gson gson = new Gson();

        // Create a JsonArray to store JSON objects
        JsonArray ordersArray = new JsonArray();

        // Process orders
        for (Order order : orders) {
            // Your code to process each order goes here
            // For example, you can add each order to the JsonArray
            JsonObject orderJson = new JsonObject();

            orderJson.addProperty("orderNo", order.getOrderNo());
            orderJson.addProperty("orderStatus", order.getOrderStatus().toString());
            orderJson.addProperty("orderValidationCode", order.getOrderValidationCode().toString());
            orderJson.addProperty("costInPence", order.getPriceTotalInPence());

            ordersArray.add(orderJson);
        }

        // Write JSON array to a file
        try (FileWriter fileWriter = new FileWriter(filePath)) {
            gson.toJson(ordersArray, fileWriter);
        } catch (IOException e) {
            e.printStackTrace();
        }



    }

    /**
     *
     * Writes the flightpath-YYYY-MM-DD.json file
     *
     * @param nodes list of nodes of the flightpath to write
     * @param filePath filepath to write to
     */
    void processFlightPathAndWriteToFile(List<Node> nodes, String filePath) {
        // Create Gson instance
        Gson gson = new Gson();

        // Create a JsonArray to store JSON objects
        JsonArray ordersArray = new JsonArray();
        // Process orders
        for (Node node : nodes) {

            // Your code to process each order goes here
            // For example, you can add each order to the JsonArray
            JsonObject orderJson = getJsonObject(node);

            ordersArray.add(orderJson);
        }

        // Write JSON array to a file
        try (FileWriter fileWriter = new FileWriter(filePath)) {
            gson.toJson(ordersArray, fileWriter);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param node Node to convert to json object
     * @return json object of node
     */
    private static JsonObject getJsonObject(Node node) {
        JsonObject orderJson = new JsonObject();

        orderJson.addProperty("orderNo", node.orderNo);
        orderJson.addProperty("fromLongitude", node.lngLat.lng());
        orderJson.addProperty("fromLatitude", node.lngLat.lat());
        orderJson.addProperty("angle", (node.angle));

        orderJson.addProperty("toLongitude", node.getToLongitude());
        orderJson.addProperty("toLatitude", node.getToLatitude());
        return orderJson;
    }
}

