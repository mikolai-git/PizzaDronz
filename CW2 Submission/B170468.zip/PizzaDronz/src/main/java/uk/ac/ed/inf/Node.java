package uk.ac.ed.inf;
import uk.ac.ed.inf.ilp.data.LngLat;

import java.util.*;

public class Node implements Comparable<Node> {

    String orderNo;
    LngLat lngLat;

    double angle;

    double toLongitude;
    double toLatitude;

    // 0-15, 0 represents east, 4 represents north, 8 represents west, 12 represents south etc...
    int directionOfTravel;
    Map<LngLat, Double> edges = new HashMap<>();
    double gCost = Double.POSITIVE_INFINITY;
    double hCost = 0;
    double fCost = 0;
    Node parent = null;

    Node(String orderNo, LngLat lngLat, int directionOfTravel) {

        this.orderNo = orderNo;
        this.lngLat = lngLat;
        this.directionOfTravel = directionOfTravel;

        if (directionOfTravel == 99 || directionOfTravel == 1179){
            this.angle = 999;
        }
        else {
            this.angle = 22.5 * directionOfTravel;
        }

    }

    //Getters

    public String getOrderNo() {
        return this.orderNo;
    }

    public LngLat getLngLat() {
        return this.lngLat;
    }

    public int getDirectionOfTravel(){
        return this.directionOfTravel;
    }

    public double getToLongitude(){
        return this.toLongitude;
    }

    public double getToLatitude(){
        return this.toLatitude;
    }

    public double getAngle() {
        return angle;
    }

    //Setters

    public void setToLongitude(double toLongitude){
        this.toLongitude = toLongitude;
    }
    public void setToLatitude(double toLatitude) {
        this.toLatitude = toLatitude;
    }

    public void setAngle(double angle){
        this.angle = angle;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    void addEdge(LngLat direction, double cost) {
        edges.put(direction, cost);
    }

    @Override
    public int compareTo(Node others) {
        return Double.compare(this.fCost, others.fCost);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Node other = (Node) obj;
        return Objects.equals(lngLat, other.lngLat);
    }

    @Override
    public int hashCode() {
        return Objects.hash(lngLat);
    }

}
